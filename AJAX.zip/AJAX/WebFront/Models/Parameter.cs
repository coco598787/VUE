﻿namespace WebFront.Models
{
    public class Parameter
    {
        public string Name { get; set; }
    }
}