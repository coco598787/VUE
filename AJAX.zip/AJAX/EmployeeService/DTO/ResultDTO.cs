﻿namespace EmployeeService.DTO
{
    public class ResultDTO
    {
        public bool Ok { get; set; }
        public int Code { get; set; }
    }
}